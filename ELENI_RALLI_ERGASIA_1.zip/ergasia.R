#ELENI RALLI
#Student ID: f2822312
#SOCAIL NETWORK ANALYSIS
#PROJECT 1



rm(list = ls())
print(ls()) # List all variables loaded
setwd("D:/social net analysis") # D:\social net analysis   # Set the working directory to the folder containing the .Rdata file




#LOADING LIBRARIES AND DATA

library(igraph)              # install.packages("igraph")  #igraph is used for network analysis
library(tidyverse)            #tidyverse for data manipulation
asoiaf_data <- read.csv("asoiaf-all-edges.csv")  # Read the CSV file using base R's read.csv function



head(asoiaf_data) # View the first few rows of the data frame to check it
str(asoiaf_data)
summary(asoiaf_data)

#_____________________________________________________________________________________________________________________________
#1

# Create the igraph object using only Source, Target, and Weight columns
g <- graph_from_data_frame(d = asoiaf_data[, c("Source", "Target", "weight")], directed = FALSE)
g

#An undirected weighted graph is created using the igraph package,
#with vertices representing characters and edges representing their interactions.
#_________________________________________________________________________________________________________________________
#2

cat("Number of vertices:", vcount(g), "\n")

cat("List of vertices:\n") ; print(V(g)$name)

cat("Number of edges:", ecount(g), "\n")

cat("List of edges:\n") ; print(get.data.frame(g, what = "edges"))

cat("Diameter of the graph:", diameter(g, directed = FALSE, weights = NA), "\n")

cat("Number of triangles:", sum(count_triangles(g)), "\n")

heavy_edges <- E(g)[weight > 12]
cat("Number of edges with weight > 12:", length(heavy_edges), "\n")

degree_table <- sort(degree(g), decreasing = TRUE)
cat("Top-10 characters by degree:\n"); print(head(degree_table, 10))

weighted_degree_table <- sort(strength(g, weights = E(g)$weight), decreasing = TRUE)
cat("Top-10 characters by weighted degree:\n");print(head(weighted_degree_table, 10))

clust_coeff_table <- sort(transitivity(g, type = "local"), decreasing = TRUE)
cat("Top-10 characters by local clustering coefficient:\n") ;print(head(clust_coeff_table, 10))

cat("Global clustering coefficient:", transitivity(g, type = "global"), "\n")
#___________________________________________________________________________________________________
#3
# Plotting the entire network
plot(g,
     vertex.label=NA,  # Hides vertex labels
     vertex.size=5,    # Sets size of the vertices
     edge.arrow.size=.5,  # Sets size of arrow heads (if applicable)
     edge.arrow.width=1,  # Sets width of arrows
     vertex.color="dodgerblue",  # Color of vertices
     edge.color="grey50",     # Color of edges
     main="Full Network Visualization")


# Creating a subgraph by filtering vertices based on degree
sub_g <- induced_subgraph(g, degree(g) >= 9)
# Plotting the subgraph
plot(sub_g,
     vertex.label=NA,  # Hides vertex labels
     vertex.size=7,    # Sets size of the vertices
     edge.arrow.size=.5,  # Sets size of arrow heads (if applicable)
     edge.arrow.width=1.2,  # Sets width of arrows
     vertex.color="dodgerblue",  # Color of vertices
     edge.color="grey70",       # Color of edges
     main="Subgraph with Degree >= 9")

# Edge density of the entire graph
density_full <- edge_density(g)
cat("Edge density of the full graph:", density_full, "\n")

# Edge density of the subgraph
density_sub <- edge_density(sub_g)
cat("Edge density of the subgraph:", density_sub, "\n")

#_______________________________________________________________________________________________________________
#4
# Calculate Closeness Centrality
closeness_centrality <- closeness(g, normalized = FALSE)
# Top-15 nodes by Closeness Centrality
top_closeness <- sort(closeness_centrality, decreasing = TRUE)
cat("Top-15 nodes by Closeness Centrality:\n") ; print(head(top_closeness, 15))

# Calculate Betweenness Centrality
betweenness_centrality <- betweenness(g, normalized = FALSE)
# Top-15 nodes by Betweenness Centrality
top_betweenness <- sort(betweenness_centrality, decreasing = TRUE)
cat("Top-15 nodes by Betweenness Centrality:\n") ; print(head(top_betweenness, 15))



# Ranking of Jon Snow in Closeness Centrality
jon_snow_closeness_rank <- rank(-closeness_centrality, ties.method = "min")[which(names(closeness_centrality) == "Jon-Snow")]
cat("Jon Snow's rank by Closeness Centrality:", jon_snow_closeness_rank, "\n")

# Ranking of Jon Snow in Betweenness Centrality
jon_snow_betweenness_rank <- rank(-betweenness_centrality, ties.method = "min")[which(names(betweenness_centrality) == "Jon-Snow")]
cat("Jon Snow's rank by Betweenness Centrality:", jon_snow_betweenness_rank, "\n")

#______________________________________________________________________________________________________________
#5

# Calculate PageRank
page_rank_values <- page_rank(g, directed = FALSE)$vector

# Print PageRank values
cat("PageRank values:\n") ; print(page_rank_values)


# Sort and print the top characters by PageRank
top_pagerank <- sort(page_rank_values, decreasing = TRUE)
cat("Top characters by PageRank:\n"); print(head(top_pagerank, n = 10))  # Print top 10 characters


# Plot the network graph
plot(g,
     vertex.size = sqrt(page_rank_values) * 100,  # Set vertex sizes based on PageRank values
     vertex.label = NA,  # Hide vertex labels for clarity
     vertex.color = "dodgerblue",  # Set vertex color
     edge.color = "grey70",  # Set edge color
     main = "Network Graph with Node Sizes Based on PageRank",  # Main title of the plot
     edge.arrow.size = .5,  # Size of the arrow, adjust based on network density
     layout = layout_with_fr(g)  # Layout algorithm, can change to layout_nicely() or others
)





